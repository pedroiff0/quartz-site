# Modelo preenchido — classe `ifftese.cls`

Rascunho didático de um TCC **completo e preenchido** (dados fictícios), usando
`ifftese.cls` + `macros.sty` + `metadados.sty`. O objetivo não é ser um TCC de
verdade — é te mostrar, com sintaxe real e funcionando, como cada comando é
usado na prática, comentado linha a linha nos próprios arquivos `.tex`.

Leia estes três arquivos junto com este modelo, nesta ordem:

1. **Aula 06 — Classe `ifftese.cls`** — o que cada flag/comando faz por dentro.
2. **Aula 07 — Pacote `macros.sty`** — as macros de conteúdo (capa, figuras, ambientes de teorema).
3. **Aula 08 — Arquivo `metadados.sty`** — este arquivo, explicado campo a campo.

(as três estão em `pt-br/resource/latex/` no site.)

Para slides de defesa e pôster científico, veja os modelos e aulas
**separados**, construídos sobre os templates reais do IFF Campus Bom Jesus
do Itabapoana (não sobre `ifftese.cls`):

- **Aula 09 — Slides com o template oficial do IFFBJI** + `modelo-slide-iffbji.zip`
- **Aula 10 — Pôster com `iffposter.cls`** + `modelo-iffposter-banner.zip`

## Estrutura do pacote

```
metadados.sty                    ← comece por aqui: troque os dados fictícios pelos seus
TCC-Modelo.tex                   ← arquivo principal do TCC (ordem de montagem do documento)
01-introducao.tex                ← seções, siglas/símbolos, \index
02-fundamentacao-teorica.tex     ← ambientes definicao/exemplo/observacao, glossário
03-metodologia-e-resultados.tex  ← figuras, tabelas, quadros, gráficos, algoritmo
04-consideracoes-finais.tex      ← capítulo de fechamento
apendices.tex                    ← \capituloapendice + problema/desafio/exercício com resposta cruzada
anexos.tex                       ← \capituloanexo
referencias.bib                  ← bibliografia (abntex2cite/BibTeX)
img/exemplo-arquitetura.png      ← imagem placeholder — troque pelas suas figuras/gráficos reais
ifftese.cls, macros.sty          ← a classe e o pacote de macros (não precisam de edição)
```

## Como compilar

```
pdflatex TCC-Modelo
bibtex TCC-Modelo      # ou biber, se preferir
pdflatex TCC-Modelo
pdflatex TCC-Modelo    # 3-4 passadas mesmo: sumário, listas de figuras,
                       # siglas/símbolos, glossário e o índice remissivo
                       # dependem de dados gravados no .aux na passada
                       # anterior (o índice remissivo roda automaticamente
                       # via shell-escape restrito, se sua instalação permitir)
```

Funciona em qualquer distribuição LaTeX moderna (TeX Live, MacTeX, MiKTeX) ou
no Overleaf — basta subir os arquivos deste pacote como um projeto novo e
compilar `TCC-Modelo.tex`.

## Nota honesta (e o que já foi corrigido)

Este pacote já foi **realmente compilado** (TeX Live completo,
`pdflatex`/`bibtex`/`makeindex`, 4 passadas) até produzir um PDF de 34
páginas sem erros. No processo, dois bugs reais apareceram e foram
corrigidos, tanto aqui quanto no `ifftese.cls`/`macros.sty` originais:

1. **`\inserirfigura`/`\inserirfluxograma`/`\inserirelementografico`** tinham um espaço a mais em `\figuracaminho/ #2` dentro de `macros.sty` — quebrava com "arquivo não encontrado". Corrigido (removido o espaço, alinhado com `\inserirgrafico`, que já não tinha o bug).
2. **`\listofsaidas`** (dentro de `ifftese.cls`) chamava `\disableRectoSections` sozinha, sem as outras `\listofX` fazerem o mesmo — corrompia `\section` a partir da 2ª passada de compilação. Corrigido (linha removida). Detalhe completo na [Aula 06, §5.3](pt-br/resource/latex/aula-06-classe-ifftese).
3. **Ordem de `\imprimirglossario`**: precisa vir depois de qualquer `\begin{resolucao}{...}` (problema/desafio/exercício), não antes — na ordem errada, os labels de resposta cruzada silenciosamente deixam de ser gravados. Ver comentário em `TCC-Modelo.tex`.

Se você já tinha uma cópia mais antiga de `ifftese.cls`/`macros.sty`, vale atualizar.
