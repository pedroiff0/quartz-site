# Modelo preenchido — classe `slidesiffmodelo.cls`

Slides usando o template oficial de slides do IFF Campus Bom Jesus do
Itabapoana, com o mesmo conteúdo científico real usado por mim no pôster:
o trabalho descrito em [Detecção de Anomalias em Dados do Gaia](pt-br/research/anomaly-detection)
(Etapa 1, já publicada) — catálogos Gaia GCNS e GALAH DR4, os mesmos 4
gráficos de resultado (Kiel, Toomre, Tinsley-Wallerstein, [Fe/H]×[Mg/Fe]) e
conclusões. Título e um dos autores ficam como campos de exemplo genéricos,
prontos para você substituir pelos seus dados ao reaproveitar o modelo.

Leia junto com a **Aula 09 — Slides com `slidesiffmodelo.cls`**
(`pt-br/resource/latex/aula-09-slides-beamer`), que documenta cada
flag/comando da classe em detalhe.

## Estrutura do pacote

```
metadados.sty        ← header/footer/logos dos slides (comece por aqui)
main.tex              ← título, autores, e os frames (Introdução...Referências)
slidesiffmodelo.cls   ← a classe (não precisa editar)
referencias.bib        ← bibliografia citada nos slides (abntex2cite/BibTeX)
capa/                  ← cabeçalho do evento (Mostra do Conhecimento) e logos de fomento (FAPERJ/CNPq)
img/                   ← as figuras reais usadas nos slides
```

## Como compilar

```
pdflatex main
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

Testado com TeX Live completo — 15 páginas, sem erros, referência
bibliográfica resolvida (há uma citação real, `\cite{Bovy2015}`, no slide do
Diagrama de Toomre).

Funciona em qualquer distribuição LaTeX moderna ou no Overleaf.

## Nota sobre as opções de frame `[img]`/`[small]`

`\begin{frame}[img]` já ativa fonte reduzida automaticamente (útil para
frames com imagem grande, que sobra pouco espaço de texto); `[small]` faz só
a parte da fonte, sem supor imagem. Ver Aula 09, Seção 5.
