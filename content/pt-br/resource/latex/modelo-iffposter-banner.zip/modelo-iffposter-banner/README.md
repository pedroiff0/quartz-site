# Modelo preenchido — classe `iffposter.cls`

Este é um pôster científico **real**, já usado por mim: o mesmo trabalho
descrito em [Detecção de Anomalias em Dados do Gaia](pt-br/research/anomaly-detection)
(Etapa 1, já publicada), formatado para a **XIV Mostra do Conhecimento e VII
Feira de Oportunidades do IFF Campus Bom Jesus do Itabapoana**, usando a
classe oficial do evento, `iffposter.cls`.

Diferente do modelo de TCC (que usa dados fictícios de propósito), aqui os
dados são reais — inclusive o meu ORCID, a orientação da Prof.ª Dr.ª Maria
Luiza Linhares Dantas e os resultados científicos (228 estrelas candidatas a
halo, idade mediana ≈1,6 Ga etc.). É o mesmo material já apresentado
publicamente em pôster na [SAB 2025](pt-br/media/2025/sab-2025) e na
[Escola de Inverno do ON (2026)](pt-br/media/2026/escolainverno-2026).

Leia junto com a **Aula 10 — Pôster com `iffposter.cls`**
(`pt-br/resource/latex/aula-10-poster-cientifico`), que documenta cada
flag/comando da classe em detalhe.

## Estrutura do pacote

```
metadados.sty     ← flags de tamanho/cor/cabeçalho-rodapé/logos (comece por aqui)
main.tex          ← título, autores, e as 4 seções do pôster (Introdução...Conclusões)
iffposter.cls     ← a classe (não precisa editar)
referencias.bib   ← bibliografia completa da pesquisa (abntex2cite/BibTeX)
capa/             ← cabeçalho do evento (Mostra do Conhecimento) e logos de fomento (FAPERJ/CNPq)
img/              ← as 4 figuras reais do pôster (Kiel, Toomre, Tinsley-Wallerstein, Fe/H×Mg/Fe)
```

## Como compilar

```
pdflatex main
bibtex main
pdflatex main
pdflatex main
```

Testado com TeX Live completo — 1 página, sem erros, referências completas
(a versão original, antes de eu enxugar a seção de Conclusões, transbordava
5 linhas de bibliografia para uma 2ª página — cuidado com isso ao adicionar
texto: pôster é documento de página única).

Funciona em qualquer distribuição LaTeX moderna ou no Overleaf.

## Nota sobre a opção `maior`

`\documentclass[]{iffposter}` usa o preset "menor" (70×100cm). Para o
tamanho A0 padrão de congresso (90×120cm, fontes bem maiores), troque para
`\documentclass[maior]{iffposter}` — ver Aula 10, Seção 5.
